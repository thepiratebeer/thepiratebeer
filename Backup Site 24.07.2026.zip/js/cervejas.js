const cervejas = [

/*{
    nome: "⚫ Czech Premium ARAMIS",
    ibu: 38,
    abv: "5.3%",
    preco: 20,
    estoque: 30
},
*/

{
    nome: "🟣 Scotish Export",
    ibu: 17,
    abv: "6.8%",
    estoque: 50,
    preco: 24,
    descricao: "Scottish Export de corpo médio, rica em malte, com notas de caramelo, toffee e leve tostado. Um discreto toque defumado proveniente do malte Peat Smoked complementa o conjunto sem dominar o sabor. Amargor moderado, final limpo e excelente equilíbrio entre dulçor e secura."
}

/*{
    nome: "🔵 Rauchbier Bacon MATURANDO",
    ibu: 24,
    abv: "5%",
    preco: 20,
    estoque: 0
}


{
    nome: "🟡 APA CITRA PRODUÇÃO",
    ibu: 40,
    abv: "5,5%",
    preco: 20,
    estoque:0
}
*/


/* 🟡 ⚫ 🔴 🟣 🟢 🔵 ⚪ 🟠 */
/* 🍺 🍻 🍺 🍻 🍺 */

];