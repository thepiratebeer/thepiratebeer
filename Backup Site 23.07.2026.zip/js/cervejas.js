const cervejas = [

/*{
    nome: "⚫ Czech Premium ARAMIS",
    ibu: 38,
    abv: "5.3%",
    preco: 20,
    estoque: 30
},
*/

{
    nome: "🔴 Scotish ALE",
    ibu: 18,
    abv: "6.6%",
    preco: 24,
    estoque:50
},

{
    nome: "🔵 Rauchbier Bacon MATURANDO",
    ibu: 24,
    abv: "5%",
    preco: 20,
    estoque: 0
},


{
    nome: "🟡 APA CITRA PRODUÇÃO",
    ibu: 40,
    abv: "5,5%",
    preco: 20,
    estoque:0
}




/* 🟡 ⚫ 🔴 🟣 🟢 🔵 ⚪ 🟠 */


];